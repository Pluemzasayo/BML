---
name: Bangkok Metro Editorial
colors:
  surface: '#faf8ff'
  surface-dim: '#d2d9f4'
  surface-bright: '#faf8ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f3ff'
  surface-container: '#eaedff'
  surface-container-high: '#e2e7ff'
  surface-container-highest: '#dae2fd'
  on-surface: '#131b2e'
  on-surface-variant: '#404947'
  inverse-surface: '#283044'
  inverse-on-surface: '#eef0ff'
  outline: '#707978'
  outline-variant: '#bfc8c7'
  surface-tint: '#2d6764'
  primary: '#003533'
  on-primary: '#ffffff'
  primary-container: '#0a4d4a'
  on-primary-container: '#83bdb8'
  inverse-primary: '#97d1cd'
  secondary: '#006c48'
  on-secondary: '#ffffff'
  secondary-container: '#56feb7'
  on-secondary-container: '#00734d'
  tertiary: '#003341'
  on-tertiary: '#ffffff'
  tertiary-container: '#004b5f'
  on-tertiary-container: '#6cbcdb'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#b3eee9'
  primary-fixed-dim: '#97d1cd'
  on-primary-fixed: '#00201e'
  on-primary-fixed-variant: '#0e4f4c'
  secondary-fixed: '#56feb7'
  secondary-fixed-dim: '#2be19d'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005235'
  tertiary-fixed: '#b9eaff'
  tertiary-fixed-dim: '#81d1f0'
  on-tertiary-fixed: '#001f29'
  on-tertiary-fixed-variant: '#004d62'
  background: '#faf8ff'
  on-background: '#131b2e'
  surface-variant: '#dae2fd'
typography:
  display-hero:
    fontFamily: Space Grotesk
    fontSize: 56px
    fontWeight: '700'
    lineHeight: 64px
    letterSpacing: -0.03em
  display-hero-mobile:
    fontFamily: Space Grotesk
    fontSize: 36px
    fontWeight: '700'
    lineHeight: 42px
    letterSpacing: -0.02em
  headline-xl:
    fontFamily: Space Grotesk
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 34px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.015em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 22px
    fontWeight: '600'
    lineHeight: 30px
    letterSpacing: -0.01em
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '600'
    lineHeight: 24px
  body-lg:
    fontFamily: Work Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 30px
    letterSpacing: -0.005em
  body-md:
    fontFamily: Work Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 26px
  body-sm:
    fontFamily: Work Sans
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 22px
  label-lg:
    fontFamily: Work Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.02em
  label-md:
    fontFamily: Work Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.04em
  label-ticker:
    fontFamily: Space Grotesk
    fontSize: 13px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.06em
  caption:
    fontFamily: Work Sans
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 18px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  space-2xs: 0.25rem
  space-xs: 0.5rem
  space-sm: 0.75rem
  space-md: 1rem
  space-lg: 1.5rem
  space-xl: 2rem
  space-2xl: 3rem
  space-3xl: 4rem
  gutter-mobile: 1rem
  gutter-tablet: 1.5rem
  gutter-desktop: 2rem
  margin-mobile: 1rem
  margin-tablet: 2rem
  margin-desktop: 3rem
  container-max-width: 1280px
---

## Brand & Style

This design system embodies the vibrant, architectural pulse of Southeast Asia's premier metropolis through a clean, authoritative Minimal Metro Editorial framework. Built for an audience of discerning urban commuters, expatriates, dynamic locals, and global travelers, the brand communicates sophistication, kinetic urban movement, and journalistic credibility. 

The emotional tone balances metropolitan pace with editorial composure: crisp lines, generous whitespace, confident architectural sans-serif typography, and tactical bursts of vibrant mint. The visual direction takes inspiration from contemporary broadsheet publications, transit wayfinding systems, and curated lifestyle periodicals. The design avoids visual clutter in favor of strict compositional rhythm, structured hairline dividers, high information density balanced by expansive image treatments, and real-time transit and lifestyle indicators.

## Colors

The color palette is derived directly from the metro teal and vibrant mint brand mark, evoking both Bangkok’s transit architecture (BTS/MRT lines, modern glass towers) and lush equatorial serenity.

- **Primary (`#0a4d4a`):** Deep Metro Emerald. Anchors mastheads, primary headlines, active states, key navigation elements, and architectural badges.
- **Secondary (`#2de29e`):** Electric Mint. A high-contrast energetic accent used intentionally for live breaking indicators, active transit route trackers, bookmark triggers, and interactive focus states.
- **Tertiary (`#0e7490`):** River Teal. An intermediate deep aqua for utility pills, category tags (e.g., Transit & Commute), and secondary visual data.
- **Neutral Core (`#0f172a`):** Deep Slate Black. Used for body typography and high-contrast editorial titles to maintain readability over extended sessions.
- **Surface & Canvas:** Surfaces sit on an ultra-clean warm off-white canvas (`#f8faf9`) framed by subtle structural borders (`#e2e8f0` and `#cbd5e1`), avoiding pure sterile white for a more tactile, editorial feel.

## Typography

The typographic hierarchy couples **Space Grotesk** for display headlines with **Work Sans** for extended editorial reading and operational labels. 

- **Display & Headings:** Space Grotesk introduces subtle geometric and brutalist nuances that echo modern rapid transit wayfinding, signage, and contemporary urban publications. Negative letter spacing is calibrated for high impact in editorial cards and cover features.
- **Body & Long-Form Reading:** Work Sans provides open apertures, neutral proportions, and high legibility across screens of all sizes, rendering English prose with effortless flow.
- **Labels & Metas:** Uppercase, tracked-out label treatments are used across tickers, category metadata, transit indicators, and bylines, providing structure without visual weight.

## Layout & Spacing

This design system uses a strict 12-column responsive fluid grid pinned within a maximum container width of `1280px` for optimal long-form readability and balanced visual pacing.

- **Desktop (1024px+):** 12 columns with `2rem` (32px) gutters and `3rem` (48px) exterior margins. Editorial features span either 8 columns (primary body) + 4 columns (contextual transit/status sidebar & trending feeds) or a balanced 4-4-4 card array for lifestyle discovery.
- **Tablet (768px - 1023px):** 8 columns with `1.5rem` (24px) gutters and `2rem` (32px) margins. Sidebars collapse underneath primary features or translate into swipable cards.
- **Mobile (< 768px):** 4 columns with `1rem` (16px) gutters and `1rem` (16px) safe margins. Content stacks vertically with full-bleed image opportunities paired with structured padding.

Vertical rhythm relies on baseline increments of `0.5rem` (8px). Editorial sections are separated by structural hairline borders rather than arbitrary white gaps to maintain a disciplined newspaper-like organization.

## Elevation & Depth

This system avoids heavy drop shadows and faux-3D layering. In line with the Minimal Metro Editorial aesthetic, depth is established through:

- **Low-Contrast Outlines & Hairlines:** Crisp 1px borders (`#e2e8f0`) segment columns, article blocks, and header tiers. Active or high-priority cards utilize a 1.5px accent line or Deep Metro Emerald framing.
- **Tonal Layers:** Visual hierarchy relies on surface nesting. The page background rests on `#f8faf9`, cards sit on `#ffffff`, and inset editorial modules (such as live transit trackers or sponsored perspectives) utilize a subtle `#f1f5f4` wash.
- **Surface Framing:** Modals, navigation overlays, and floating utility sheets employ a delicate, diffused ambient shadow: `0 8px 30px rgba(10, 77, 74, 0.08)`, gently tinted with deep metro green to maintain atmospheric cohesion.

## Shapes

The system implements a refined, architectural curvature level (`1` - Soft). 

- Standard components (cards, text inputs, transit status panels, and feature thumbnails) utilize a crisp `0.25rem` (4px) border radius, conveying precision, discipline, and journalistic structure.
- Interactive tags, utility pills, and category chips utilize a slightly softened `0.5rem` (8px) corner to distinctively separate actionable data from structural containers.
- Transit bullet badges, status indicator dots, and breaking news live pulses remain strictly circular (`9999px`).

## Components

### Buttons
- **Primary:** Solid Deep Metro Emerald (`#0a4d4a`) background, white text (`#ffffff`), 4px corner radius, bold `Space Grotesk` or `Work Sans` medium weight. On hover, background shifts to `#0d5c58` with a micro-offset transition.
- **Secondary / Ghost:** Transparent background with a 1.5px border in `#0a4d4a` and matching text. Hover state fills background with a 10% opacity wash of `#2de29e`.
- **Accent Action:** Electric Mint (`#2de29e`) fill with Deep Slate Black (`#0f172a`) text for urgent callouts, subscriptions, or interactive transit updates.

### Ticker Banner (Breaking News & Live Transit)
- A full-width, low-height ribbon pinned below the primary navigation. Background is deep emerald (`#0a4d4a`) or deep slate (`#0f172a`). Features an uppercase live badge (`#2de29e` pill) followed by a horizontal scrolling headline feed in `Space Grotesk`, separated by geometric diamond or slash glyphs.

### Cards & Editorial Modules
- **Hero Story Card:** Dominant editorial image with an aspect ratio of 16:9 or 3:2, accompanied by an uppercase category pill (e.g., "URBAN LIVING", "TRANSIT INTEL"), high-contrast `Space Grotesk` headline, author/time byline, and a hairline bottom divider.
- **List Article Card:** Horizontal thumbnail (1:1 aspect ratio) positioned on the right, headline and timestamp on the left, separated by a light border (`#e2e8f0`).
- **Transit Status Widget:** Clean, modular utility card showing BTS, MRT, and Chao Phraya Express boat statuses. Uses color-coded transit indicators (green for normal, amber for delay) paired with clear micro-typography.

### Chips & Tags
- **Category Chips:** Minimalist borders with warm neutral fills (`#ffffff` on `#f1f5f4`). Text is uppercase `label-md` in `#0a4d4a`. Active state features a solid `#0a4d4a` background with white text and a mint highlight dot.
- **Status Pills:** Compact rounded indicators featuring a blinking live mint dot (`#2de29e`) for breaking updates and real-time transit status.

### Form Inputs & Checkboxes
- **Input Fields:** `#ffffff` surface, 1px `#cbd5e1` outline, 4px corner radius, and `Work Sans` 14px typography. Focused state triggers a 1.5px `#0a4d4a` border with a subtle mint glow (`0 0 0 3px rgba(45, 226, 158, 0.25)`).
- **Checkboxes & Radios:** Crisp square (4px radius) or circular elements with an emerald border. Checked states feature solid `#0a4d4a` fill and an electric mint checkmark or center pip.